using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "9d7c38cf47d45cd282db82b478ed5f5d")]
public class IPA_Label : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "b81028049b6d72ba15252331a5762ab1")]
public class Overview : FTOptix.UI.Window
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "81032b0e6a74d3c4080ff9b331edf5cf")]
public class Trend : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "ae3dc24d2ef9e8c662879a01eece8960")]
public class Packaging : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "7c399c94ce06f8436a77abcdb044b0eb")]
public class Back_to_Overview : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "921348e482deb0389f83ad2edbcc06e3")]
public class BLENDING : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "4d5ec6b9b5382f5e67652d1a2757b59e")]
public class Labeling : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "f45352bda509d6e75fdf8399a71ceb19")]
public class Recipes : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "981e630384970eeda4d76be0b67b583e")]
public class Filling : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "1a48e1b25c22214b229f0462ca54fb56")]
public class Alarms : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "aebc8a51a342312769901f28dace275c")]
public class Stout_Label : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "57adaf34cecc8f4d3945b44f83322f4a")]
public class Pilsner_Label : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "09f7ebde579bcf776a6ff384673fa520")]
public class Hazy_IPA_Label : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "InstaFizz_Optix_1", Guid = "a795a035a7130008e2c4c63ceffa7345")]
public class Pale_Ale_Label : FTOptix.UI.Panel
{
}
