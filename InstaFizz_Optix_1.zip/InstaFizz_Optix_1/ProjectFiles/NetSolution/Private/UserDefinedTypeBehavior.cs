using System;
using UAManagedCore;
using FTOptix.NetLogic;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

namespace ECHO_TEST
{
    [Behaviour("f0d00f0d355b915e9945f34db35e98d6")]
    public class UserDefinedTypeBehavior : BaseUserDefinedTypeBehavior
    {
        public UserDefinedTypeBehavior(IUANode node)
            : base(node)
        {
        }
    }
}
