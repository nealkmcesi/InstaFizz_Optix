using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

namespace InstaFizz_Optix_1
{
    public static class ObjectTypes
    {
        private static readonly int namespaceIndex = NamespaceMapProvider.GetNamespaceIndex("InstaFizz_Optix_1");
        public static readonly NodeId IPA_Label = new NodeId(namespaceIndex, new Guid("9d7c38cf47d45cd282db82b478ed5f5d"));
        public static readonly NodeId Overview = new NodeId(namespaceIndex, new Guid("b81028049b6d72ba15252331a5762ab1"));
        public static readonly NodeId Trend = new NodeId(namespaceIndex, new Guid("81032b0e6a74d3c4080ff9b331edf5cf"));
        public static readonly NodeId Packaging = new NodeId(namespaceIndex, new Guid("ae3dc24d2ef9e8c662879a01eece8960"));
        public static readonly NodeId Back_to_Overview = new NodeId(namespaceIndex, new Guid("7c399c94ce06f8436a77abcdb044b0eb"));
        public static readonly NodeId BLENDING = new NodeId(namespaceIndex, new Guid("921348e482deb0389f83ad2edbcc06e3"));
        public static readonly NodeId Labeling = new NodeId(namespaceIndex, new Guid("4d5ec6b9b5382f5e67652d1a2757b59e"));
        public static readonly NodeId Recipes = new NodeId(namespaceIndex, new Guid("f45352bda509d6e75fdf8399a71ceb19"));
        public static readonly NodeId Filling = new NodeId(namespaceIndex, new Guid("981e630384970eeda4d76be0b67b583e"));
        public static readonly NodeId Alarms = new NodeId(namespaceIndex, new Guid("1a48e1b25c22214b229f0462ca54fb56"));
        public static readonly NodeId Stout_Label = new NodeId(namespaceIndex, new Guid("aebc8a51a342312769901f28dace275c"));
        public static readonly NodeId Pilsner_Label = new NodeId(namespaceIndex, new Guid("57adaf34cecc8f4d3945b44f83322f4a"));
        public static readonly NodeId Hazy_IPA_Label = new NodeId(namespaceIndex, new Guid("09f7ebde579bcf776a6ff384673fa520"));
        public static readonly NodeId Pale_Ale_Label = new NodeId(namespaceIndex, new Guid("a795a035a7130008e2c4c63ceffa7345"));
    }

    public static class VariableTypes
    {
        private static readonly int namespaceIndex = NamespaceMapProvider.GetNamespaceIndex("InstaFizz_Optix_1");
    }
}
